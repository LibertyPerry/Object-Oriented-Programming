
public interface Colorable {
	public abstract String howToColor();
}
